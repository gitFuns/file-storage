<template>
	<div class="hrx-button">按钮</div>
</template>

<script>
	export default {
		name: 'hrxButton'
	}
</script>