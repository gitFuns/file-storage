const routes = [
  {
    path: '/',
    redirect: '/component',
    children: [
      {
        path: 'button',
        component: {
          template: '<div>i am button component</div>'
        }
      }
    ]
  }
]

export default routes
