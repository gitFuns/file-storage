<template>
	<div class="home-page">
    <router-view></router-view>
	</div>
</template>

<script>
	export default {
	}
</script>
